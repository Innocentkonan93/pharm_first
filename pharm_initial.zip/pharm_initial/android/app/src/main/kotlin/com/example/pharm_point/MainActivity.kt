package com.example.pharm_point

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
