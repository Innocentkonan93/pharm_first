import 'package:flutter/material.dart';

class ForgetScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}