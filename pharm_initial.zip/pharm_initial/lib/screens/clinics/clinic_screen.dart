import 'package:flutter/material.dart';

class ClinicScreen extends StatelessWidget {
  static const nameRoute = '/clinic';
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
