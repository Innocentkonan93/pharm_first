import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SanteScreen extends StatelessWidget {
  static const nameRoute = 'centre-sante';
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
